package ch.m183.BrokenAccessControllDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrokenAccessControllDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
